﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoubleTakeProxyService.DimensionData.Models
{
    class Option
    {
        public String option { get; set; }
        public String value { get; set; }
    }
}
